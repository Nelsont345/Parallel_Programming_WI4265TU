#include <stdio.h>
#include <mpi.h>

int main()
{
  /* Continue here ... */

  return 0;
}
