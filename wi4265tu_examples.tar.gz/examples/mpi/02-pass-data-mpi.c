
#include <stdio.h>
#include <mpi.h>

int main ( int argc, char** argv )
{
  /* Continue here ... */

  return 0;
}
