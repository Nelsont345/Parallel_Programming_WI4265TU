
#include <stdio.h>
#include <pthread.h>

/* ---------------------------------------------------------------------
 * types
 * ------------------------------------------------------------------ */

struct                    fifo
{
  /* Implement the FIFO buffer data type here ... */
};

typedef struct fifo       fifo_t;


/* ---------------------------------------------------------------------
 * producer()
 * ------------------------------------------------------------------ */

void*                     producer

  ( void*                   arg )

{
  /* Implement the producer thread here ... */

  return NULL;
}

/* ---------------------------------------------------------------------
 * consumer()
 * ------------------------------------------------------------------ */

void*                     consumer

  ( void*                   arg )

{
  /* Implement the consumer thread here ... */

  return NULL;
}

/* ---------------------------------------------------------------------
 * main()
 * ------------------------------------------------------------------ */

int                       main

( int                     argc,
  char**                  argv )

{
  /* Implement the main thread here ... */

  return 0;
}
